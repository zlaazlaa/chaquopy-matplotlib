# for backwards compatibility
from llama_index.core.base_retriever import BaseRetriever

__all__ = [
    "BaseRetriever",
]
