# for backwards compatibility
from llama_index.schema import QueryBundle, QueryType

__all__ = ["QueryBundle", "QueryType"]
