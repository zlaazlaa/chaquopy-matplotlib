# for backwards compatibility
from llama_index.core.base_query_engine import BaseQueryEngine

__all__ = [
    "BaseQueryEngine",
]
