# for backwards compatibility
from llama_index.service_context import ServiceContext

__all__ = [
    "ServiceContext",
]
