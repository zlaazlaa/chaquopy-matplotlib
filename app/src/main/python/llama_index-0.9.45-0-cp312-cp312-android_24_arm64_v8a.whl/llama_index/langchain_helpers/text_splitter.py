# backward compatibility
from llama_index.text_splitter import *
