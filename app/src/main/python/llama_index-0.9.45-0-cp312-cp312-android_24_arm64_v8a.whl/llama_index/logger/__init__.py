"""Init params."""

from llama_index.logger.base import LlamaLogger

__all__ = ["LlamaLogger"]
